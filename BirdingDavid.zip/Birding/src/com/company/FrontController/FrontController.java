package com.company.FrontController;

public class FrontController {
}
