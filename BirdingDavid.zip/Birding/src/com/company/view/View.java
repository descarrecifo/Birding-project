package com.company.view;
import com.company.controller.Controller;

import java.util.Scanner;

public class View {
    static Scanner scanner = new Scanner(System.in);
    public static void menu() {

            System.out.println("**********************");
            System.out.println("*        MENU        *");
            System.out.println("* 0. Quit            *");
            System.out.println("* 1. Add Bird        *");
            System.out.println("* 2. Modify Bird     *");
            System.out.println("* 3. Add Observation *");
            System.out.println("* 4. Show All        *");
            System.out.println("* 5. Search Bird     *");
            System.out.println("**********************");

    }
    public static void menuOptions() {
        while (true) {
            //the variable exit is used to break the while loop
            boolean exit = false;

            //with the method ask, we give a value to choose
            menu();
            int valueScanner = Integer.parseInt(ask(scanner , "Choose an option:"));

            //the different cases of the switch
            switch (valueScanner) {
                case 0 -> exit = true;
                case 1 -> {
                    System.out.println("Chosen Option 1");
                    Controller.addBird();
                }
                case 2 -> {
                    System.out.println("Chosen Option 2");
                    Controller.modifyBird();
                }
                case 3 -> {
                    System.out.println("Chosen Option 3");
                    Controller.addObservation();
                }

                case 4 -> {
                    System.out.println("Chosen Option 4");
                    Controller.showBirds();
                }

                case 5 -> {
                    System.out.println("Chosen Option 5");
                    Controller.searchBird();
                }

                default -> System.out.println("Invalid option chosen. Please try again\n");
            }
            if (exit) break;
        }
    }

    //this method receives the scanner and a String and returns
    //the output of the scanner inserted by the user
    public static String ask(Scanner scanner , String text) {
        System.out.println(text);
        return scanner.next();
    }


}
