package com.company.controller;

import java.util.HashMap;
import java.util.Scanner;

public class Controller {
    static Scanner scanner = new Scanner(System.in);
    HashMap<String,String> hashMapBird = new HashMap<>();
    public static void addBird() {
        System.out.println("Add bird");
        System.out.print("Name: ");
        String nameBird = scanner.nextLine();
        System.out.print("NameLatin: ");
        String nameLatinBird = scanner.nextLine();
        System.out.print("Observations: ");
        String obervationsBird= scanner.nextLine();
        hashMapBird.put("name",)
    }

    public static void modifyBird() {
        System.out.println("Modify bird\n");




    }

    public static void addObservation() {
        System.out.println("Add bird\n");
    }

    public static void showBirds() {
        System.out.println("Add bird\n");
    }

    public static void searchBird() {
    }
}


