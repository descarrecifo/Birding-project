package com.company;

public class BirdDatabase {
}