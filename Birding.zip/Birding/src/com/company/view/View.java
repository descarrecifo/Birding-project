package com.company.view;public class View {
}
